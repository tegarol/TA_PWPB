    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <!-- Antrian Section -->
            <div class="row justify-content-center">
                <div class="col-12 col-lg-6 col-xl-5">
                    <div class="card">
                        <div class="card-header text-center">
                            <h4 class="font-weight-bold">Antrian</h4>
                        </div>
                        <div class="card-body text-center">
                            <?php if($DataCustomer) : ?>
                                <h1>No <?= $DataCustomer[0]->Id; ?></h1>
                                <p class="m-0 p-0">Atas Nama</p>
                                <h1><?= $DataCustomer[0]->Nama; ?></h1>
                                <form action="<?= site_url('home/antrian'); ?>" method="POST">
                                    <input type="hidden" name="id" value="<?= $DataCustomer[0]->Id; ?>">
                                    <button type="submit" name="status" class="btn btn-success btn-block my-1" value="1">
                                        <i class="fas fa-check-circle mr-1"></i>Ada Dalam Antrian
                                    </button>
                                    <button type="submit" name="status" class="btn btn-outline-info btn-block my-1" value="2">
                                        <i class="fas fa-minus-circle mr-1"></i>Tidak Dalam Antrian
                                    </button>
                                </form>
                            <?php else : ?>
                                <h1>Tidak Ada Antrian</h1>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Antrian End Section -->
            <!-- Main row -->
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="d-lg-inline">Daftar Antrian Customer</h4>
                            <button type="button" class="btn btn-success float-lg-right" data-toggle="modal" data-target="#modal-default"><i class="fas fa-plus mr-1"></i>Tambah Antrian</button>   
                        </div>

                        <div class="card-body p-0">
                            <table class="table table-info table-bordered">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Nama Customer</th>
                                        <th>NIK customer</th>
                                        <th>Kendala</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $no = 1; 
                                    foreach($DataCustomer as $item) : ?>
                                        <tr>
                                            <td><?= $no++; ?></td>
                                            <td><?= $item->Id; ?></td>
                                            <td><?= $item->Nama; ?></td>
                                            <td><?= $item->NIK; ?></td>
                                            <td><?= $item->Kendala; ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.row (main row) -->
        </div><!-- /.container-fluid -->

        <!-- Modal -->
        <div class="modal fade" id="modal-default">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">Tambah Data Antrian Customer</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form action="<?= site_url('antrian/create') ?>" method="POST" class="mx-3 mb-5">
                            <div class="form-group mb-0">
                                <label for="NIK" class="col-form-label">No Identitas</label>
                                <input type="text" id="NIK" name="NIK" class="form-control">
                            </div>
                            <div class="form-group mb-0">
                                <label for="Nama" class="col-form-label">Nama</label>
                                <input type="text" id="Nama" name="Nama" class="form-control">
                            </div>
                            <div class="form-group mb-0">
                                <label for="Keluhan" class="col-form-label">Kendala</label>
                                <input type="text" id="Keluhan" name="Keluhan" class="form-control">
                            </div>
                            <div class="form-group mt-3">
                                <button type="submit" class="btn btn-success btn-block">Submit</button>
                                <button type="button" class="btn btn-default btn-block" data-dismiss="modal">Close</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.model-content -->

    </section>
    <!-- /.modal-dialog -->
</div>
<!-- End Modal -->