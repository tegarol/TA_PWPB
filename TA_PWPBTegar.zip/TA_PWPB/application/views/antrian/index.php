<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?= base_url('assets/') ?>plugins/fontawesome-free/css/all.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="<?= base_url('assets/') ?>plugins/icheck-bootstrap/icheck-bootstrap.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?= base_url('assets/') ?>dist/css/adminlte.min.css">
    <title>Antrian</title>
</head>
<body>
    <div class="container">
        <div class="row vh-100 justify-content-center align-items-center">
            <div class="col-11 col-md-6 col-lg-5">
                <div class="card">
                    <div class="card-header text-center bg-success">
                        <h4 class="font-weight-bold">Antrian</h4>
                    </div>
                    <div class="card-body text-center">
                        <?php if($Antrian) : ?>
                            <h1>No <?= $Antrian->Id; ?></h1>
                            <p class="m-0 p-0">Atas Nama</p>
                            <h1><?= $Antrian->Nama; ?></h1>
                        <?php else : ?>
                            <h1>Tidak Ada Antrian</h1>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <footer class="text-center fixed-bottom text-info" style="height: 40px;">
        <strong>Made With Tegar</strong>
    </footer>

    <!-- jQuery -->
    <script src="<?= base_url('assets/') ?>plugins/jquery/jquery.min.js"></script>
    <!-- Bootstrap 4 -->
    <script src="<?= base_url('assets/') ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- AdminLTE App -->
    <script src="<?= base_url('assets/') ?>dist/js/adminlte.js"></script>
</body>
</html>